﻿// See https://aka.ms/new-console-template for more information

using Verlag;

Buch b = new("sdfg", "dsfsf");
b.ISBN13 = "978-377043614";

Console.WriteLine(b.ISBN13);